import React from 'react';
// import { BrowserRouter as Router, Route,Link,Switch,Routes } from 'react-router-dom';
import Main from './component/Mains/Main';
// import Login from './component/Login'
function App() {
  
  return (
    <div>
      <Main/>
      {/* <Login/>   */}
    </div>
  );
}

export default App;
