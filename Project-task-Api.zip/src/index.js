import React,{useEffect} from 'react';
import ReactDOM from 'react-dom';
import App from './App';

import { Provider} from 'react-redux';
import store from './services/store';
// import Categories from './component/Categories';
import './css/Categories.css';





ReactDOM.render(
 

  <Provider store={store}>
  <App/>
    {/* <Categories /> */}
  </Provider>,
  document.getElementById('root')
);
