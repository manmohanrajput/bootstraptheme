import React from 'react';
import Main from './component/Mains/Main';
// import Login from './component/Login'
function App() {
  
  return (
    <div>
      <Main/>
      {/* <Login/> */}  project Could not proceed due to some technical issues
    </div>
  );
}

export default App;
