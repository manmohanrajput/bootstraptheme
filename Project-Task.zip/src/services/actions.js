// src/redux/actions.js

export const SET_CATEGORY = 'SET_CATEGORY';

export const setCategory = (category) => ({
  type: SET_CATEGORY,
  payload: category,
});
